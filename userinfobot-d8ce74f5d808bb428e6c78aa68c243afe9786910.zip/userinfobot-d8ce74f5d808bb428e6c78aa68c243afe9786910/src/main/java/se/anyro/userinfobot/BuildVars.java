package se.anyro.userinfobot;

public class BuildVars {
    public static final int OWNER = // Your user id here. Send message to @userinfobot to get it.
    public static final String TOKEN = // Your bot token here. Use @BotFather.
}
